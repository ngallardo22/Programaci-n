package BibliotecaApp;

import java.io.*;
import java.util.*;

abstract class Material implements Serializable {
    private String codigo;
    private String titulo;
    private boolean disponible;
    private int diasPrestado;

    public Material(String codigo, String titulo, boolean disponible, int diasPrestado) {
        this.codigo = codigo;
        this.titulo = titulo;
        this.disponible = disponible;
        this.diasPrestado = diasPrestado;
    }

    public String getCodigo() { return codigo; }
    public String getTitulo() { return titulo; }
    public boolean isDisponible() { return disponible; }
    public int getDiasPrestado() { return diasPrestado; }

    public void prestar(int dias) {
        if (disponible) {
            disponible = false;
            diasPrestado = dias;
        }
    }

    public void devolver() {
        disponible = true;
        diasPrestado = 0;
    }

    public abstract void mostrarInfo();
}

class Libro extends Material {
    private String autor;
    private boolean esDigital;

    public Libro(String codigo, String titulo, String autor, boolean disponible, int diasPrestado, boolean esDigital) {
        super(codigo, titulo, disponible, diasPrestado);
        this.autor = autor;
        this.esDigital = esDigital;
    }

    public void mostrarInfo() {
        System.out.println("Libro: " + getTitulo() + " | Autor: " + autor + " | Tipo: " + (esDigital ? "Digital" : "Físico") + " | Disponible: " + isDisponible());
    }
}

class Revista extends Material {
    private int numeroEdicion;

    public Revista(String codigo, String titulo, boolean disponible, int diasPrestado, int numeroEdicion) {
        super(codigo, titulo, disponible, diasPrestado);
        this.numeroEdicion = numeroEdicion;
    }

    public void mostrarInfo() {
        System.out.println("Revista: " + getTitulo() + " | Edición: " + numeroEdicion + " | Disponible: " + isDisponible());
    }
}

public class Bibioteca {
    private static List<Material> materiales = new ArrayList<>();
    private static final String ARCHIVO = "materiales.dat";

    public static void main(String[] args) {
        cargarDatos();
        Scanner sc = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("1. Ver disponibles\n2. Prestar\n3. Devolver\n4. Ver prestados\n5. Registrar material\n6. Salir");
            opcion = sc.nextInt();
            sc.nextLine();
            switch (opcion) {
                case 1: verDisponibles(); break;
                case 2: prestarMaterial(sc); break;
                case 3: devolverMaterial(sc); break;
                case 4: verPrestados(); break;
                case 5: registrarMaterial(sc); break;
                case 6: guardarDatos(); System.out.println("Hasta luego."); break;
                default: System.out.println("Opción inválida");
            }
        } while (opcion != 6);
    }

    private static void verDisponibles() {
        for (Material m : materiales) {
            if (m.isDisponible()) m.mostrarInfo();
        }
    }

    private static void prestarMaterial(Scanner sc) {
        System.out.print("Código del material a prestar: ");
        String codigo = sc.nextLine();
        for (Material m : materiales) {
            if (m.getCodigo().equals(codigo) && m.isDisponible()) {
                System.out.print("Días de préstamo: ");
                int dias = sc.nextInt();
                m.prestar(dias);
                System.out.println("Préstamo realizado.");
                return;
            }
        }
        System.out.println("No disponible o no encontrado.");
    }

    private static void devolverMaterial(Scanner sc) {
        System.out.print("Código del material a devolver: ");
        String codigo = sc.nextLine();
        for (Material m : materiales) {
            if (m.getCodigo().equals(codigo) && !m.isDisponible()) {
                m.devolver();
                System.out.println("Devolución realizada.");
                return;
            }
        }
        System.out.println("No se encuentra prestado.");
    }

    private static void verPrestados() {
        for (Material m : materiales) {
            if (!m.isDisponible()) {
                m.mostrarInfo();
                System.out.println("Días prestado: " + numeroATexto(m.getDiasPrestado()));
            }
        }
    }

    private static void registrarMaterial(Scanner sc) {
        System.out.print("¿Deseas registrar un libro (L) o una revista (R)? ");
        String tipo = sc.nextLine().toUpperCase();

        System.out.print("Código: ");
        String codigo = sc.nextLine();

        System.out.print("Título: ");
        String titulo = sc.nextLine();

        if (tipo.equals("L")) {
            System.out.print("Autor: ");
            String autor = sc.nextLine();

            System.out.print("¿Es digital? (true/false): ");
            boolean esDigital = sc.nextBoolean();
            sc.nextLine();

            materiales.add(new Libro(codigo, titulo, autor, true, 0, esDigital));
            System.out.println("Libro registrado correctamente.");
        } else if (tipo.equals("R")) {
            System.out.print("Número de edición: ");
            int edicion = sc.nextInt();
            sc.nextLine();

            materiales.add(new Revista(codigo, titulo, true, 0, edicion));
            System.out.println("Revista registrada correctamente.");
        } else {
            System.out.println("Tipo no válido.");
        }
    }

    private static String numeroATexto(int numero) {
        String[] textos = {"cero", "uno", "dos", "tres", "cuatro", "cinco", "seis", "siete", "ocho", "nueve", "diez", "once", "doce", "trece", "catorce", "quince", "dieciséis", "diecisiete", "dieciocho", "diecinueve", "veinte"};
        if (numero >= 0 && numero <= 20) {
            return textos[numero];
        }
        return String.valueOf(numero);
    }

    private static void cargarDatos() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ARCHIVO))) {
            materiales = (List<Material>) ois.readObject();
        } catch (Exception e) {
            System.out.println("No se pudo cargar archivo. Se inicia vacío.");
            materiales = new ArrayList<>();
        }
    }

    private static void guardarDatos() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ARCHIVO))) {
            oos.writeObject(materiales);
        } catch (IOException e) {
            System.out.println("Error al guardar datos.");
        }
    }
}

